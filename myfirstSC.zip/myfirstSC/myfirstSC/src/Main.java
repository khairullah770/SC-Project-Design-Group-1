import javax.swing.SwingUtilities;

import presentation.UserLoginForm;

public class Main {
     public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new UserLoginForm().setVisible(true);
        });
    }
}
