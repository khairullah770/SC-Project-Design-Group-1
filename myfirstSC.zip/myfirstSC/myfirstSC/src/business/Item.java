package business;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import database.DatabaseConnection;

public class Item {
    private int id; // Adding id attribute
    private String name;
    private double startPrice;
    private String description;
    private String picturePath;
    private int sellerId;

    // Constructor for creating a new item
    public Item(String name, double startPrice, String description, String picturePath, int sellerId) {
        this.name = name;
        this.startPrice = startPrice;
        this.description = description;
        this.picturePath = picturePath;
        this.sellerId = sellerId;
    }

    // Constructor for existing items with id
    public Item(int id, String name, double startPrice, String description, String picturePath, int sellerId) {
        this.id = id;
        this.name = name;
        this.startPrice = startPrice;
        this.description = description;
        this.picturePath = picturePath;
        this.sellerId = sellerId;
    }

    // Getter methods
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getStartPrice() {
        return startPrice;
    }

    public String getDescription() {
        return description;
    }

    public String getPicturePath() {
        return picturePath;
    }

    public int getSellerId() {
        return sellerId;
    }

    public void saveToDatabase() throws SQLException {
        String sql = "INSERT INTO Items (title, description, start_price, auction_duration, seller_id, status) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, name);
            statement.setString(2, description);
            statement.setDouble(3, startPrice);
            statement.setString(4, "14"); // Assuming default auction duration is 14 days
            statement.setInt(5, sellerId);
            statement.setString(6, "active");

            statement.executeUpdate();
        }
    }
}
