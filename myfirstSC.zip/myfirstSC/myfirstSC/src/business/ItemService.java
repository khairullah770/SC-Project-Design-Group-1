package business;

import technical.ItemDAO;
import java.util.List;

public class ItemService {
    private final ItemDAO itemDAO;

    public ItemService() {
        itemDAO = new ItemDAO();
    }

    public List<Item> getAllItems() {
        return itemDAO.getAllItems();
    }

    public void removeItem(int itemId) {
        itemDAO.removeItem(itemId);
    }
}
