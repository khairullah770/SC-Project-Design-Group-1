package business;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import database.DatabaseConnection;
import technical.UserDAO;

public class UserService {

    private final UserDAO userDAO;

    public UserService() {
        userDAO = new UserDAO();
    }

    public boolean registerUser(String name, String email, String password, String role) {

      if  (userDAO.insertUser(name, email, password, role)){
        return true;

      }
      return false;
        
    }

    public String authenticateUser(String email, String password) {
        return userDAO.getUserRole(email, password);
    }
    public List<String> getSellerNames() {
      List<String> sellerNames = new ArrayList<>();
      String sql = "SELECT name FROM user WHERE role = 'seller'";

      try (Connection connection = DatabaseConnection.getConnection();
           PreparedStatement statement = connection.prepareStatement(sql);
           ResultSet resultSet = statement.executeQuery()) {
          
          while (resultSet.next()) {
              sellerNames.add(resultSet.getString("name"));
          }
      } catch (SQLException e) {
          e.printStackTrace();
      }

      return sellerNames;
  }

  public void rateSeller(String sellerName, int rating) {
      String sql = "UPDATE user SET rating = ? WHERE name = ?";

      try (Connection connection = DatabaseConnection.getConnection();
           PreparedStatement statement = connection.prepareStatement(sql)) {
          
          statement.setInt(1, rating);
          statement.setString(2, sellerName);
          statement.executeUpdate();
      } catch (SQLException e) {
          e.printStackTrace();
      }
  }
}

