package controller;
import business.UserService;

public class Controller {
    // private List<User> users;

    public Controller() {
        // users = new ArrayList<>();
    }

    public String registerUser(String name, String email, String password, String role) {
        UserService newuser=new UserService();
        if(newuser.registerUser(name,email,password,role)){
            return "Registered Sucessfully";
        }
        return "unsucessful";
       
    }



    public String authenticateUser(String email, String password) {
        UserService loginuser=new UserService();
     if(loginuser.authenticateUser(email,password)!=null){
       return loginuser.authenticateUser(email,password);
    }

        return "User Not Exists";
 
}
}
