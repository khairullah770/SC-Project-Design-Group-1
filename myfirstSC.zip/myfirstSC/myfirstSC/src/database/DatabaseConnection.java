package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {

    private static final String URL = "jdbc:mysql://localhost:3306/auctiondb";
    private static final String USER = "root";
    private static final String PASSWORD = ""; // Ensure the password is correct and has no spaces

    public static Connection getConnection() {
        Connection connection = null;
        try {
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Connection established successfully!");
        } catch (SQLException e) {
            System.err.println("Failed to establish connection!");
            e.printStackTrace(); // Print stack trace to understand the error
        }
        return connection;
    }

    // public static void main(String[] args) {
    //     // Test the connection
    //     Connection conn = DatabaseConnection.getConnection();
    //     if (conn != null) {
    //         try {
    //             conn.close();
    //             System.out.println("Connection closed successfully!");
    //         } catch (SQLException e) {
    //             e.printStackTrace(); // Handle any errors while closing the connection
    //         }
    //     }
    // }
}
