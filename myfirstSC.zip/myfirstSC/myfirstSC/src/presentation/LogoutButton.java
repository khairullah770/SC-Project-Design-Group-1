package presentation;

public class LogoutButton {

}
