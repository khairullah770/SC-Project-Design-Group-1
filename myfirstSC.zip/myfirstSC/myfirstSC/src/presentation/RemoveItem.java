package presentation;

import business.Item;
import business.ItemService;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class RemoveItem extends JFrame {

    private final List<Item> itemList;
    private final JComboBox<String> itemComboBox;
    private final JTextArea itemTextArea;
    private final ItemService itemService;

    public RemoveItem() {
        setTitle("Remove Listed Items");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        itemService = new ItemService();
        itemList = itemService.getAllItems();

        Container container = getContentPane();
        container.setLayout(new BorderLayout());

        // Panel for item selection
        JPanel selectionPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        selectionPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel selectLabel = new JLabel("Select Item:");
        selectLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        selectionPanel.add(selectLabel);

        itemComboBox = new JComboBox<>();
        itemComboBox.setFont(new Font("Arial", Font.PLAIN, 16));
        for (Item item : itemList) {
            itemComboBox.addItem(item.getName());
        }
        itemComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                displaySelectedItem();
            }
        });
        selectionPanel.add(itemComboBox);

        container.add(selectionPanel, BorderLayout.NORTH);

        // Panel for displaying item details
        JPanel itemPanel = new JPanel(new BorderLayout());
        itemPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        itemTextArea = new JTextArea(10, 30);
        itemTextArea.setEditable(false);
        itemTextArea.setFont(new Font("Arial", Font.PLAIN, 16));
        itemPanel.add(new JScrollPane(itemTextArea), BorderLayout.CENTER);

        container.add(itemPanel, BorderLayout.CENTER);

        // Panel for buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));

        JButton removeButton = new JButton("Remove");
        removeButton.setFont(new Font("Arial", Font.PLAIN, 16));
        removeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                removeSelectedItem();
            }
        });
        buttonPanel.add(removeButton);

        JButton backButton = new JButton("Back");
        backButton.setFont(new Font("Arial", Font.PLAIN, 16));
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                backToAdminDashboard();
            }
        });
        buttonPanel.add(backButton);

        container.add(buttonPanel, BorderLayout.SOUTH);

        pack();
        setLocationRelativeTo(null); // Center the window on the screen
        setVisible(true);
    }

    private void displaySelectedItem() {
        String selectedItemName = (String) itemComboBox.getSelectedItem();
        if (selectedItemName != null) {
            for (Item item : itemList) {
                if (item.getName().equals(selectedItemName)) {
                    itemTextArea.setText("Name: " + item.getName() + "\n"
                            + "Description: " + item.getDescription() + "\n"
                            + "Price: $" + item.getStartPrice());
                    break;
                }
            }
        }
    }

    private void removeSelectedItem() {
        String selectedItemName = (String) itemComboBox.getSelectedItem();
        if (selectedItemName != null) {
            for (Item item : itemList) {
                if (item.getName().equals(selectedItemName)) {
                    itemService.removeItem(item.getId());
                    itemList.remove(item);
                    itemComboBox.removeItem(selectedItemName);
                    itemTextArea.setText("");
                    JOptionPane.showMessageDialog(this, "Item removed successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    break;
                }
            }
        }
    }

    private void backToAdminDashboard() {
        new AdminDashboard().setVisible(true);
        dispose();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(RemoveItem::new);
    }
}
