package presentation;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import controller.Controller;

public class UserLoginForm extends JFrame {

    private final JTextField emailField;
    private final JPasswordField passwordField;
    private final JButton loginButton;
    private final JButton registerButton; // New register button
    private final Controller controller;

    public UserLoginForm() {
        setTitle("User Login");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Create UI elements
        JLabel titleLabel = new JLabel("User Login", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));

        emailField = new JTextField(20);
        passwordField = new JPasswordField(20);

        loginButton = new JButton("Login");
        registerButton = new JButton("Register"); // Initialize register button

        // Add action listeners
        loginButton.addActionListener((ActionEvent e) -> {
            login();
        });

        registerButton.addActionListener((ActionEvent e) -> {
            register();
        });

        // Create panels for layout
        JPanel panel = new JPanel(new GridLayout(3, 2));
        panel.add(new JLabel("Email:"));
        panel.add(emailField);
        panel.add(new JLabel("Password:"));
        panel.add(passwordField);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.add(loginButton);
        buttonPanel.add(registerButton); // Add register button to the panel

        // Add components to the frame
        setLayout(new BorderLayout());
        add(titleLabel, BorderLayout.NORTH);
        add(panel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        // Initialize the controller
        controller = new Controller();
    }

    private void login() {
        String email = emailField.getText();
        String password = new String(passwordField.getPassword());

        // Perform login validation
        if (validateLogin(email, password)) {
            // Call the controller method to handle login
            String role = controller.authenticateUser(email, password);
            if (role != null) {
                JOptionPane.showMessageDialog(this, "Login successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
                navigateToDashboard(role);
                dispose(); // Close the login form
            } else {
                JOptionPane.showMessageDialog(this, "Invalid email or password", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private boolean validateLogin(String email, String password) {
        // Validate that none of the fields are empty
        return !email.isEmpty() && !password.isEmpty();
    }

    private void navigateToDashboard(String role) {
        switch (role) {
            case "admin":
                new AdminDashboard().setVisible(true);
                break;
            case "seller":
                new sellerdashboard().setVisible(true);
                break;
            case "buyer":
                new BidderDashboard().setVisible(true);
                break;
            default:
                throw new IllegalStateException("Unexpected role: " + role);
        }
    }

    private void register() {
        // Logic to navigate to user registration form
        UserRegistrationForm registrationForm = new UserRegistrationForm();
        registrationForm.setVisible(true);
        dispose(); // Dispose the current frame
    }
    //     public static void main(String[] args) {
    //     SwingUtilities.invokeLater(() -> {
    //         new UserLoginForm().setVisible(true);
    //     });
    // }
}

