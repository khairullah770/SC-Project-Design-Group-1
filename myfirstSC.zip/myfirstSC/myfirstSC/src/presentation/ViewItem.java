package presentation;
import business.Item;
import business.ItemService;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class ViewItem extends JFrame {

    private final JTextArea itemTextArea;
    private final ItemService itemService;

    public ViewItem() {
        setTitle("View Listed Items");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        itemService = new ItemService();

        Container container = getContentPane();
        container.setLayout(new BorderLayout());

        // Panel for displaying items
        JPanel itemPanel = new JPanel(new BorderLayout());
        itemPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        itemTextArea = new JTextArea(10, 30);
        itemTextArea.setEditable(false);
        itemTextArea.setFont(new Font("Arial", Font.PLAIN, 16));
        itemPanel.add(new JScrollPane(itemTextArea), BorderLayout.CENTER);

        displayItems(); // Display items initially

        container.add(itemPanel, BorderLayout.CENTER);

        // Panel for back button
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton backButton = new JButton("Back");
        backButton.setFont(new Font("Arial", Font.PLAIN, 16));
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Go back to SellerDashboard
                new sellerdashboard().setVisible(true);
                dispose();
            }
        });
        buttonPanel.add(backButton);
        container.add(buttonPanel, BorderLayout.SOUTH);

        pack();
        setLocationRelativeTo(null); // Center the window on the screen
        setVisible(true);
    }

    private void displayItems() {
        List<Item> itemList = itemService.getAllItems();
        StringBuilder sb = new StringBuilder();
        for (Item item : itemList) {
            sb.append("Name: ").append(item.getName()).append("\n");
            sb.append("Description: ").append(item.getDescription()).append("\n");
            sb.append("Price: $").append(item.getStartPrice()).append("\n\n");
        }
        itemTextArea.setText(sb.toString());
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ViewItem::new);
    }
}
