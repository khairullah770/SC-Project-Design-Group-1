package technical;

import business.Item;
import database.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ItemDAO {
    public List<Item> getAllItems() {
        List<Item> items = new ArrayList<>();
        String query = "SELECT id, title, description, start_price, seller_id FROM Items";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("title");
                String description = resultSet.getString("description");
                double startPrice = resultSet.getDouble("start_price");
                int sellerId = resultSet.getInt("seller_id");
                items.add(new Item(id, name, startPrice, description, null, sellerId)); // Assuming picturePath is not fetched for simplicity
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return items;
    }

    public void removeItem(int itemId) {
        String query = "DELETE FROM Items WHERE id = ?";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setInt(1, itemId);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
