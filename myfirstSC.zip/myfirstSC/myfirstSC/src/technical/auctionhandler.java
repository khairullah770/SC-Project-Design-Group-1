package technical;

public class auctionhandler {
    
}
