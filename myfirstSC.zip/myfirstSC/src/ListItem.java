import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class ListItem extends JFrame implements ActionListener {

    private final JTextField itemNameField;
    private final JTextField minimumPriceField;
    private final JLabel itemPictureLabel;
    private final JTextField itemDescriptionField;
    private final JButton uploadButton;
    private final JButton addButton;
    private final JButton backButton;

    private File itemPictureFile; // Stores the uploaded item picture file

    public ListItem() {
        setTitle("List Item for Auction");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setPreferredSize(new Dimension(600, 400)); // Set preferred size
        setResizable(false);

        Container container = getContentPane();
        container.setLayout(new BorderLayout());

        // Panel for item details
        JPanel detailsPanel = new JPanel(new GridLayout(4, 2, 10, 10));
        detailsPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel itemNameLabel = new JLabel("Item Name:");
        itemNameLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        detailsPanel.add(itemNameLabel);

        itemNameField = new JTextField();
        itemNameField.setFont(new Font("Arial", Font.PLAIN, 16));
        detailsPanel.add(itemNameField);

        JLabel minimumPriceLabel = new JLabel("Minimum Price:");
        minimumPriceLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        detailsPanel.add(minimumPriceLabel);

        minimumPriceField = new JTextField();
        minimumPriceField.setFont(new Font("Arial", Font.PLAIN, 16));
        detailsPanel.add(minimumPriceField);

        JLabel itemPictureUploadLabel = new JLabel("Upload Item Picture:");
        itemPictureUploadLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        detailsPanel.add(itemPictureUploadLabel);

        JPanel picturePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        uploadButton = new JButton("Upload");
        uploadButton.setFont(new Font("Arial", Font.PLAIN, 16));
        uploadButton.addActionListener(this);
        picturePanel.add(uploadButton);

        itemPictureLabel = new JLabel();
        itemPictureLabel.setPreferredSize(new Dimension(200, 200));
        picturePanel.add(itemPictureLabel);

        detailsPanel.add(picturePanel);

        JLabel itemDescriptionLabel = new JLabel("Item Description:");
        itemDescriptionLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        detailsPanel.add(itemDescriptionLabel);

        itemDescriptionField = new JTextField();
        itemDescriptionField.setFont(new Font("Arial", Font.PLAIN, 16));
        detailsPanel.add(itemDescriptionField);

        container.add(detailsPanel, BorderLayout.CENTER);

        // Panel for buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        addButton = new JButton("Add");
        addButton.setFont(new Font("Arial", Font.PLAIN, 16));
        addButton.addActionListener(this);
        buttonPanel.add(addButton);

        backButton = new JButton("Back");
        backButton.setFont(new Font("Arial", Font.PLAIN, 16));
        backButton.addActionListener(this);
        buttonPanel.add(backButton);

        container.add(buttonPanel, BorderLayout.SOUTH);

        pack();
        setLocationRelativeTo(null); // Center the window on the screen
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == uploadButton) {
            JFileChooser fileChooser = new JFileChooser();
            int returnValue = fileChooser.showOpenDialog(this);
            if (returnValue == JFileChooser.APPROVE_OPTION) {
                itemPictureFile = fileChooser.getSelectedFile();
                itemPictureLabel.setIcon(new ImageIcon(itemPictureFile.getAbsolutePath()));
            }
        } else if (e.getSource() == addButton) {
            addItem();
        } else if (e.getSource() == backButton) {
            // Navigate back to the sellerdashboard
            SwingUtilities.invokeLater(() -> {
                sellerdashboard dashboard = new sellerdashboard();
                dashboard.setVisible(true);
            });
            // Close the ListItem window
            dispose();
        }
    }

    private void addItem() {
        String itemName = itemNameField.getText();
        String minimumPrice = minimumPriceField.getText();
        String itemDescription = itemDescriptionField.getText();

        if (itemName.isEmpty() || minimumPrice.isEmpty() || itemDescription.isEmpty() || itemPictureFile == null) {
            JOptionPane.showMessageDialog(this, "Please fill all fields and upload item picture", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Item Added Successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            clearFields();
        }
    }

    private void clearFields() {
        itemNameField.setText("");
        minimumPriceField.setText("");
        itemDescriptionField.setText("");
        itemPictureLabel.setIcon(null);
        itemPictureFile = null;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ListItem());
    }
}
