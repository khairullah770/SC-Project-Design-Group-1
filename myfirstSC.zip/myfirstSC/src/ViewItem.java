import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

public class ViewItem extends JFrame {

    private final List<Item> itemList;
    private final JTextArea itemTextArea;

    public ViewItem() {
        setTitle("View Listed Items");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        // Dummy data for demonstration
        itemList = new ArrayList<>();
        itemList.add(new Item("Item 1", "Description for item 1", 100));
        itemList.add(new Item("Item 2", "Description for item 2", 150));
        itemList.add(new Item("Item 3", "Description for item 3", 200));

        Container container = getContentPane();
        container.setLayout(new BorderLayout());

        // Panel for displaying items
        JPanel itemPanel = new JPanel(new BorderLayout());
        itemPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        itemTextArea = new JTextArea(10, 30);
        itemTextArea.setEditable(false);
        itemTextArea.setFont(new Font("Arial", Font.PLAIN, 16));
        itemPanel.add(new JScrollPane(itemTextArea), BorderLayout.CENTER);

        displayItems(); // Display items initially

        container.add(itemPanel, BorderLayout.CENTER);

        // Panel for back button
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton backButton = new JButton("Back");
        backButton.setFont(new Font("Arial", Font.PLAIN, 16));
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Go back to SellerDashboard
                new sellerdashboard().setVisible(true);
                dispose();
            }
        });
        buttonPanel.add(backButton);
        container.add(buttonPanel, BorderLayout.SOUTH);

        pack();
        setLocationRelativeTo(null); // Center the window on the screen
        setVisible(true);
    }

    private void displayItems() {
        StringBuilder sb = new StringBuilder();
        for (Item item : itemList) {
            sb.append("Name: ").append(item.getName()).append("\n");
            sb.append("Description: ").append(item.getDescription()).append("\n");
            sb.append("Price: $").append(item.getPrice()).append("\n\n");
        }
        itemTextArea.setText(sb.toString());
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ViewItem::new);
    }

    class Item {
        private final String name;
        private final String description;
        private final double price;

        public Item(String name, String description, double price) {
            this.name = name;
            this.description = description;
            this.price = price;
        }

        public String getName() {
            return name;
        }

        public String getDescription() {
            return description;
        }

        public double getPrice() {
            return price;
        }
    }
}
